# Llama 3.1 8B Abliterated model server

Pinned model: `mannix/llama3.1-8b-abliterated:q5_k_m`.

## Linux + Docker

```bash
mkdir -p secrets
python3 -c 'import pathlib,secrets; p=pathlib.Path("secrets/model_gateway_key"); p.touch(mode=0o600,exist_ok=False); p.write_text(secrets.token_urlsafe(48))'
docker compose up -d ollama gateway
docker compose exec ollama bash /setup/install-model.sh
```

Verify:

```bash
docker compose exec ollama ollama list
docker compose exec ollama ollama run mannix/llama3.1-8b-abliterated:q5_k_m "Say hello in one sentence."
```

To expose the authenticated gateway with Caddy, point a domain at the host, put `MODEL_DOMAIN=your-domain.example` in `.env`, then run:

```bash
docker compose --profile https up -d
```

Do not expose Ollama port 11434 publicly. In Companion → Connections, use the gateway HTTPS origin and the key stored in `secrets/model_gateway_key`.

## Mac

Run Ollama natively, then:

```bash
bash install-model.sh
python3 gateway.py
```

Put the gateway behind HTTPS before connecting the web companion.
